create view pg_stat_slru
            (name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates, stats_reset) as
SELECT name,
       blks_zeroed,
       blks_hit,
       blks_read,
       blks_written,
       blks_exists,
       flushes,
       truncates,
       stats_reset
FROM pg_stat_get_slru() s(name, blks_zeroed, blks_hit, blks_read, blks_written, blks_exists, flushes, truncates,
                          stats_reset);

alter table pg_stat_slru
    owner to gravity;

grant select on pg_stat_slru to public;

